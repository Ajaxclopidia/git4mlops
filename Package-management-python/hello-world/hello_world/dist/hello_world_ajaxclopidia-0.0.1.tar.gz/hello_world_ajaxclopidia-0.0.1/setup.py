from setuptools import setup, find_packages

setup(
    name="hello_world_ajaxclopidia",
    version="0.0.1",
    author="Muhammed",
    author_email="ajaxclopidia77@gmail.com",
    url="https://www.manifoldailearning.in",
    description="A hello-world example package",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)